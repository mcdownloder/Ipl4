const express=require('express');
const cors=require('cors');
require('dotenv').config();
const app=express();
app.use(cors());
app.use(express.json());
app.get('/',(_,res)=>res.json({ok:true,message:'Cricket API running'}));
app.listen(process.env.PORT||5000);